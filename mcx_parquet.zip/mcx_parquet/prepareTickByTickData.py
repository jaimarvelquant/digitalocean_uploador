#################################################################################### importing libraries
import requests
from datetime import datetime
import mysql.connector
import pandas as pd
import numpy as np
import traceback
import logging
import config
import sys
import os

pd.options.mode.chained_assignment = None

LOG_FILE_PATH = os.path.join(config.LOG_FILE_FOLDER, datetime.now().strftime("%d%m%Y, %H%M%S")+".log")
logging.basicConfig(filename=LOG_FILE_PATH, format="%(asctime)s: [TICK_OPT_FUT_DATA] %(message)s", level=logging.INFO)

REQ_HEADERS = {
    'Accept': 'application/json, text/javascript, */*; q=0.01', 'Accept-Encoding': 'gzip, deflate, br, zstd', 
    'Accept-Language': 'en-GB,en;q=0.8',
    'Connection': 'keep-alive',
    'Content-Length': '42',
    'Content-Type': 'application/json',
    'Host': 'www.mcxindia.com',
    'Origin': 'https://www.mcxindia.com',
    'Referer': 'https://www.mcxindia.com/market-data/bhavcopy',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132", "Brave";v="132"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"'
}

FULL_EXPIRY_DATE_AVALIABLE_FROM = datetime(2025,1,9).date()

def getDateFolder() -> dict:

    toreturn = {}

    tickDateWiseFolder = os.listdir(config.GDFL_FILES_FOLDER[0])
    tickDateWiseFolder = [ii for ii in tickDateWiseFolder if os.path.isdir(os.path.join(config.GDFL_FILES_FOLDER[0], ii))]

    for ii in tickDateWiseFolder:

        keyy = ii.split("_")[-1]
        if keyy not in toreturn:
            toreturn[keyy] = set()
        
        toreturn[keyy].add(os.path.join(config.GDFL_FILES_FOLDER[0], ii))

    return toreturn

def getMcxExpiryFromBhavCopy(tradingDate: datetime) -> dict:

    for __ in range(5):

        try:

            r2 = requests.post(url="https://www.mcxindia.com/backpage.aspx/GetDateWiseBhavCopy", json={'Date': tradingDate.strftime("%Y%m%d"), 'InstrumentName':'OPTFUT'}, headers=REQ_HEADERS)
            mcxBhavCopyResp = r2.json()

            bhavDf = pd.DataFrame(mcxBhavCopyResp['d']['Data'])
            bhavDf['Symbol'] = bhavDf['Symbol'].str.strip()

            mcxExpiryDf = bhavDf[['Symbol', 'ExpiryDate']].drop_duplicates()
            mcxExpiryDf['ExpiryDate'] = pd.to_datetime(mcxExpiryDf['ExpiryDate'], format="%d%b%Y")
            mcxExpiryDf['ExpiryAliasInSymbol'] = mcxExpiryDf['ExpiryDate'].dt.strftime("%y%b").str.upper()
            
            return {symbol: mcxExpiryDf[mcxExpiryDf['Symbol'] == symbol].drop(columns=['Symbol']).set_index("ExpiryAliasInSymbol").to_dict()['ExpiryDate'] for symbol in mcxExpiryDf['Symbol'].unique()}

        except Exception:
            pass

    return {}

def getFinalDatasetToPush(dataFilePath: str, optionInfo: dict, tableName: str, isFutureDataFile: bool) -> None:

    logging.info(f"Started processing: {dataFilePath}")

    try:

        optDataset = pd.read_csv(dataFilePath)
        optDataset.columns = [ii.strip().replace("<", "").replace(">", "").lower() for ii in optDataset.columns]
        optDataset = optDataset.rename(columns={
            "o/i": "oi", "ticker": "symbol", "open interest": "oi", "higgh": "high", "dtae": "date", "openinterest": "oi", "opne interest": "oi", 
            "open inerest": "oi", "closeq": "close", "ltq": "volume"
        })

        optDataset = optDataset[(~pd.isnull(optDataset['symbol'])) & (optDataset['volume'] != 0)]
        optDataset = optDataset.drop_duplicates(subset=['time'], keep="last")
        optDataset['symbol'] = optionInfo['symbolName']

        for columnss in ['date', 'time']:
            optDataset[columnss] = optDataset[columnss].str.strip()

        optDataset["time"] = pd.to_datetime(optDataset["time"], format="%H:%M:%S")
        optDataset["time"] = optDataset["time"].apply(lambda x: datetime(config.TODAY.year, config.TODAY.month, config.TODAY.day, x.hour, x.minute, x.second))
        
        try:
            optDataset['date'] = pd.to_datetime(optDataset['date'], format="%d/%m/%Y")
        except Exception:
            optDataset['date'] = pd.to_datetime(optDataset['date'], format="%d-%m-%Y")
        
        if not isFutureDataFile:
            optDataset['expiry'] = optionInfo['expiry']
            optDataset['strike'] = optionInfo['strike']
        
        optDataset['toKeep'] = optDataset.apply(lambda x: config.MARKET_TIMINGS[optionInfo['exchange']]['start'] <= x['time'].time() <= config.MARKET_TIMINGS[optionInfo['exchange']]['end'], axis=1)
        optDataset = optDataset[optDataset['toKeep']]
        if optDataset.empty:
            return

        optDataset = optDataset.drop(columns=['toKeep'])
        optDataset["time"] = optDataset["time"] - datetime(config.TODAY.year, config.TODAY.month, config.TODAY.day, 0)
        optDataset["time"] = optDataset["time"].dt.total_seconds()
        optDataset['open'] = optDataset['high'] = optDataset['low'] = optDataset['close'] = optDataset['ltp']
        
        optDataset["date"] = optDataset["date"].dt.strftime("%y%m%d")

        for int32Col in ["time", "date", "oi", "volume", "expiry"]:
            if int32Col not in optDataset.columns:
                continue
            optDataset[int32Col] = optDataset[int32Col].astype(np.int32)

        for int32Col in ["open", "high", "low", "close"]:
            if int32Col not in optDataset.columns:
                continue
            optDataset[int32Col] *= 100
            optDataset[int32Col] = optDataset[int32Col].astype(np.int32)

        optDataset['symbol'] = optDataset['symbol'].astype('category')

        if isFutureDataFile:
            optDataset = optDataset[['date', 'time', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'oi']]
        else:
            optDataset = optDataset[['date', 'time', 'symbol', 'strike', 'expiry', 'open', 'high', 'low', 'close', 'volume', 'oi']]

        filePath = os.path.join(config.TICK_DB_UPLOAD_DIR, f"{tableName}.csv")
        if os.path.exists(filePath):
            optDataset.to_csv(filePath, mode='a', index=False, header=False)
        else:
            optDataset.to_csv(filePath, index=False)
            
        return
    
    except Exception:
        logging.error(traceback.format_exc())

    return

def getUnderlyingName(symbolName: str) -> str:

    for __indice in config.TO_AVOID:
        if symbolName.startswith(__indice):
            return ""
    
    for __indice in VALID_INDEX_NAMES:
        if symbolName.startswith(__indice):
            return __indice
    
    return ""


if __name__ == "__main__":
    
    logging.info("Utility started.")

    try:

        DATE_FOLDERS = getDateFolder()
        if len(sys.argv) != 5:
            logging.info("Command line parameters are not passed properly.")
            exit()

        uPara = {"index": sys.argv[1].upper(), "instrument_type": sys.argv[2].lower(), "exchange": sys.argv[3].upper()}

        VALID_INDEX_NAMES = [ii.strip() for ii in sys.argv[4].split(",")]

        logging.info(f"Got following folder info {DATE_FOLDERS} for DB updation for {uPara}.")
        
        tickDbObj = mysql.connector.connect(host=config.MYSQL_TICK_HOST, user=config.MYSQL_TICK_USER, password=config.MYSQL_TICK_PASSWORD, database="tickhistoricaldb")
        tickCursorObj = tickDbObj.cursor()

        for tradingdatekey in DATE_FOLDERS:

            tradingdate = datetime.strptime(tradingdatekey, '%d%m%Y')
            fullexpiryavaliable = tradingdate.date() >= FULL_EXPIRY_DATE_AVALIABLE_FROM
            mcxExpiryDict = {} if fullexpiryavaliable else getMcxExpiryFromBhavCopy(tradingDate=tradingdate)
            tradingdate = int(tradingdate.strftime('%y%m%d'))

            for folderpath in DATE_FOLDERS[tradingdatekey]:

                logging.info(f"Processing data for {uPara['index']} {folderpath}.")

                existingfilesnamesinfolder = os.listdir(folderpath)
            
                if uPara['instrument_type'] == "future":

                    for futno in range(1, 3):

                        tableName = f"{uPara['index'].lower()}_future" if futno == 1 else f"{uPara['index'].lower()}_future{futno}"

                        tickCursorObj.execute(f"select distinct(symbol) from {tableName} where date = {tradingdate}")

                        existingSymbols = [record[0] for record in tickCursorObj.fetchall()]
                        if len(existingSymbols) != 0:
                            logging.info(f"{uPara['index']}, future data already exists for {tradingdatekey}, table name: {tableName}")
                            continue
                    
                        futurefilepath = [ii for ii in existingfilesnamesinfolder if ii.split(".")[0] == f"{uPara['index'].upper()}-{'I'*futno}"]

                        if len(futurefilepath) == 1:
                            
                            getFinalDatasetToPush(
                                dataFilePath=os.path.join(folderpath, futurefilepath[0]), 
                                optionInfo={"underlyingName": uPara['index'], "symbolName": uPara['index'], "exchange": uPara['exchange']}, 
                                tableName=tableName, 
                                isFutureDataFile=True
                            )

                        else:
                            logging.info(f"{uPara['index']}, Unable to find future file. Hence, cann't upload data, table name: {tableName}")
                        
                else:
                
                    tableName = f"{uPara['index'].lower()}_{uPara['instrument_type']}"

                    tickCursorObj.execute(f"select distinct(symbol) from {tableName} where date = {tradingdate}")
                    existingSymbols = [record[0] for record in tickCursorObj.fetchall()]

                    symbolsForWhichGDFLfilesExists = pd.DataFrame(existingfilesnamesinfolder, columns=['orifilename'])
                    symbolsForWhichGDFLfilesExists['symbol'] = symbolsForWhichGDFLfilesExists['orifilename'].apply(lambda x: x.split(".")[0])
                    symbolsForWhichGDFLfilesExists['indexname'] = symbolsForWhichGDFLfilesExists['symbol'].apply(lambda x: getUnderlyingName(symbolName=x))
                    symbolsForWhichGDFLfilesExists = symbolsForWhichGDFLfilesExists[symbolsForWhichGDFLfilesExists['indexname'] == uPara['index'].upper()]
                    instukey = "CE" if uPara['instrument_type'].upper() == "CALL" else "PE"
                    symbolsForWhichGDFLfilesExists = symbolsForWhichGDFLfilesExists[symbolsForWhichGDFLfilesExists['symbol'].str[-2:] == instukey] # selecting only those instrument for which data need to be uploaded
                    symbolsForWhichGDFLfilesExists = symbolsForWhichGDFLfilesExists[~symbolsForWhichGDFLfilesExists['symbol'].isin(existingSymbols)] # selecting only those symbols whose data is not yet uploaded in db

                    if symbolsForWhichGDFLfilesExists.empty:
                        logging.info(f"{uPara['index']}, {uPara['instrument_type']} data already exists for {tradingdatekey}.")
                        continue

                    symbolsForWhichGDFLfilesExists['expiry_strike'] = symbolsForWhichGDFLfilesExists.apply(lambda x: x['symbol'][len(x['indexname']):-2], axis=1)
                    
                    if fullexpiryavaliable:
                        symbolsForWhichGDFLfilesExists['expiry'] = symbolsForWhichGDFLfilesExists['expiry_strike'].str[:7]
                    else:
                        symbolsForWhichGDFLfilesExists['expiry'] = symbolsForWhichGDFLfilesExists['expiry_strike'].str[:5]
                        
                    symbolsForWhichGDFLfilesExists['strike'] = symbolsForWhichGDFLfilesExists.apply(lambda x: x['expiry_strike'][len(x['expiry']):], axis=1)

                    if fullexpiryavaliable:
                        symbolsForWhichGDFLfilesExists['expiry'] = pd.to_datetime(symbolsForWhichGDFLfilesExists['expiry'], format="%d%b%y")
                    else:
                        symbolsForWhichGDFLfilesExists['expiry'] = symbolsForWhichGDFLfilesExists['expiry'].apply(lambda x: mcxExpiryDict[uPara['index']][x])
                    
                    symbolsForWhichGDFLfilesExists['expiry'] = symbolsForWhichGDFLfilesExists['expiry'].dt.strftime("%y%m%d").astype(int)
                    symbolsForWhichGDFLfilesExists['strike'] = symbolsForWhichGDFLfilesExists['strike'].astype(float)
                    symbolsForWhichGDFLfilesExists = symbolsForWhichGDFLfilesExists.set_index("symbol").to_dict("index")

                    for symbolName in symbolsForWhichGDFLfilesExists:
                        getFinalDatasetToPush(
                            dataFilePath=os.path.join(folderpath, symbolsForWhichGDFLfilesExists[symbolName]['orifilename']), 
                            optionInfo={
                                "underlyingName": uPara['index'], "symbolName": symbolName, "expiry": symbolsForWhichGDFLfilesExists[symbolName]['expiry'], 
                                "strike": symbolsForWhichGDFLfilesExists[symbolName]['strike'], "exchange": uPara['exchange']
                            }, 
                            tableName=tableName, 
                            isFutureDataFile=False
                        )

    except Exception:
        logging.error(traceback.format_exc())
    
    logging.info("Utility stopped.")
