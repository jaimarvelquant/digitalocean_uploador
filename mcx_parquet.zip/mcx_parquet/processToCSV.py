#################################################################################### importing libraries
from datetime import datetime
import pandas as pd
import numpy as np
import traceback
import requests
import logging
import config
import os

pd.options.mode.chained_assignment = None

# Configuration for CSV processing
INPUT_DIR = "input"
OUTPUT_DIR = "output"
SYMBOLS_TO_PROCESS = ["GOLDM", "SILVERM", "CRUDEOIL", "NATURALGAS"]  # Specific symbols to process

# Create output directory
os.makedirs(OUTPUT_DIR, exist_ok=True)

LOG_FILE_PATH = os.path.join(config.LOG_FILE_FOLDER, datetime.now().strftime("%d%m%Y, %H%M%S")+"_CSV_PROCESSING.log")
logging.basicConfig(filename=LOG_FILE_PATH, format="%(asctime)s: [CSV_PROCESSOR] %(message)s", level=logging.INFO)

FULL_EXPIRY_DATE_AVAILABLE_FROM = datetime(2025,1,9).date()

# HTTP headers for MCX API requests
REQ_HEADERS = {
    'Accept': 'application/json, text/javascript, */*; q=0.01', 
    'Accept-Encoding': 'gzip, deflate, br, zstd', 
    'Accept-Language': 'en-GB,en;q=0.8',
    'Connection': 'keep-alive',
    'Content-Length': '42',
    'Content-Type': 'application/json',
    'Host': 'www.mcxindia.com',
    'Origin': 'https://www.mcxindia.com',
    'Referer': 'https://www.mcxindia.com/market-data/bhavcopy',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}

def loadManualExpiryMapping() -> dict:
    """Load manual expiry mapping from CSV file"""
    
    mapping_file = "expiry_mapping.csv"
    
    if not os.path.exists(mapping_file):
        logging.warning(f"Manual expiry mapping file {mapping_file} not found")
        return {}
    
    try:
        df = pd.read_csv(mapping_file)
        df['expiry_date'] = pd.to_datetime(df['expiry_date'], format="%d/%m/%Y")
        df['expiry_alias'] = df['expiry_alias'].str.upper()
        df['symbol'] = df['symbol'].str.upper()
        
        # Create dictionary: {symbol: {expiry_alias: expiry_date}}
        result = {}
        for symbol in df['symbol'].unique():
            symbol_df = df[df['symbol'] == symbol]
            result[symbol] = dict(zip(symbol_df['expiry_alias'], symbol_df['expiry_date']))
        
        logging.info(f"Loaded manual expiry mapping for {len(result)} symbols")
        return result
        
    except Exception as e:
        logging.error(f"Error loading manual expiry mapping: {str(e)}")
        return {}

def getMcxExpiryFromBhavCopy(tradingDate: datetime) -> dict:
    """Fetch expiry dates from MCX BhavCopy API for a given trading date"""
    
    logging.info(f"Fetching expiry data from MCX API for {tradingDate.strftime('%Y-%m-%d')}")
    
    for attempt in range(5):
        try:
            r2 = requests.post(
                url="https://www.mcxindia.com/backpage.aspx/GetDateWiseBhavCopy", 
                json={'Date': tradingDate.strftime("%Y%m%d"), 'InstrumentName':'OPTFUT'}, 
                headers=REQ_HEADERS,
                timeout=10
            )
            mcxBhavCopyResp = r2.json()
            
            bhavDf = pd.DataFrame(mcxBhavCopyResp['d']['Data'])
            bhavDf['Symbol'] = bhavDf['Symbol'].str.strip()
            
            mcxExpiryDf = bhavDf[['Symbol', 'ExpiryDate']].drop_duplicates()
            mcxExpiryDf['ExpiryDate'] = pd.to_datetime(mcxExpiryDf['ExpiryDate'], format="%d%b%Y")
            mcxExpiryDf['ExpiryAliasInSymbol'] = mcxExpiryDf['ExpiryDate'].dt.strftime("%y%b").str.upper()
            
            # Create a dictionary: {symbol: {expiry_alias: expiry_date}}
            result = {
                symbol: mcxExpiryDf[mcxExpiryDf['Symbol'] == symbol]
                        .drop(columns=['Symbol'])
                        .set_index("ExpiryAliasInSymbol")
                        .to_dict()['ExpiryDate'] 
                for symbol in mcxExpiryDf['Symbol'].unique()
            }
            
            logging.info(f"Successfully fetched expiry data for {len(result)} symbols from MCX API")
            return result
            
        except Exception as e:
            logging.warning(f"Attempt {attempt+1}/5 failed to fetch MCX BhavCopy: {str(e)}")
            if attempt < 4:  # Don't sleep on last attempt
                import time
                time.sleep(1)
    
    logging.error("Failed to fetch MCX BhavCopy after 5 attempts")
    return {}

def getDateFolders() -> list:
    """Get all date folders from input directory"""
    if not os.path.exists(INPUT_DIR):
        logging.error(f"Input directory {INPUT_DIR} does not exist.")
        return []
    
    folders = []
    for item in os.listdir(INPUT_DIR):
        item_path = os.path.join(INPUT_DIR, item)
        if os.path.isdir(item_path):
            folders.append(item_path)
    
    return folders

def getFinalDatasetForCSV(dataFilePath: str, optionInfo: dict, outputFileName: str, isFutureDataFile: bool) -> None:
    """Process data file and save to CSV"""
    
    logging.info(f"Started processing: {dataFilePath}")
    
    try:
        # Read the CSV file
        optDataset = pd.read_csv(dataFilePath)
        optDataset.columns = [ii.strip().replace("<", "").replace(">", "").lower() for ii in optDataset.columns]
        optDataset = optDataset.rename(columns={
            "o/i": "oi", "ticker": "symbol", "open interest": "oi", "higgh": "high", 
            "dtae": "date", "openinterest": "oi", "opne interest": "oi", 
            "open inerest": "oi", "closeq": "close", "ltq": "volume"
        })
        
        # Filter valid data
        optDataset = optDataset[(~pd.isnull(optDataset['symbol'])) & (optDataset['volume'] != 0)]
        optDataset = optDataset.drop_duplicates(subset=['time'], keep="last")
        optDataset['symbol'] = optionInfo['symbolName']
        
        # Clean date and time columns - keep original format
        for columnss in ['date', 'time']:
            optDataset[columnss] = optDataset[columnss].str.strip()
        
        # Parse date/time for market hours filtering only
        time_parsed = pd.to_datetime(optDataset["time"], format="%H:%M:%S")
        
        try:
            date_parsed = pd.to_datetime(optDataset['date'], format="%d/%m/%Y")
        except Exception:
            date_parsed = pd.to_datetime(optDataset['date'], format="%d-%m-%Y")
        
        # Add expiry and strike for options (keep original format)
        if not isFutureDataFile:
            optDataset['expiry'] = optionInfo['expiry']
            optDataset['strike'] = optionInfo['strike']
        
        # Filter by market hours
        optDataset['toKeep'] = time_parsed.apply(lambda x: config.MARKET_TIMINGS[optionInfo['exchange']]['start'] <= x.time() <= config.MARKET_TIMINGS[optionInfo['exchange']]['end'])
        optDataset = optDataset[optDataset['toKeep']]
        
        if optDataset.empty:
            logging.info(f"No data within market hours for {dataFilePath}")
            return
        
        optDataset = optDataset.drop(columns=['toKeep'])
        
        # Set OHLC from LTP (keep original prices without multiplying by 100)
        optDataset['open'] = optDataset['high'] = optDataset['low'] = optDataset['close'] = optDataset['ltp']
        
        # Select final columns
        if isFutureDataFile:
            optDataset = optDataset[['date', 'time', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'oi']]
        else:
            optDataset = optDataset[['date', 'time', 'symbol', 'strike', 'expiry', 'open', 'high', 'low', 'close', 'volume', 'oi']]
        
        # Save to Parquet in output directory
        filePath = os.path.join(OUTPUT_DIR, f"{outputFileName}.parquet")
        if os.path.exists(filePath):
            # Read existing parquet file and append
            existingData = pd.read_parquet(filePath)
            combinedData = pd.concat([existingData, optDataset], ignore_index=True)
            combinedData.to_parquet(filePath, index=False, engine='pyarrow')
            logging.info(f"Appended data to {filePath}")
        else:
            optDataset.to_parquet(filePath, index=False, engine='pyarrow')
            logging.info(f"Created new file {filePath}")
        
        return
    
    except Exception:
        logging.error(f"Error processing {dataFilePath}: {traceback.format_exc()}")
    
    return

def getUnderlyingName(symbolName: str, validSymbols: list) -> str:
    """Extract underlying symbol name from file name"""
    for symbol in validSymbols:
        if symbolName.upper().startswith(symbol.upper()):
            return symbol.upper()
    return ""

def processFolders():
    """Main processing function"""
    
    logging.info("CSV Processing started.")
    
    try:
        dateFolders = getDateFolders()
        
        if not dateFolders:
            logging.error("No date folders found in input directory.")
            return
        
        logging.info(f"Found {len(dateFolders)} date folders to process.")
        
        for folderPath in dateFolders:
            logging.info(f"Processing folder: {folderPath}")
            
            # Extract trading date from folder name
            folderName = os.path.basename(folderPath)
            # Try to extract date from folder name (e.g., GFDLMCX_BACKADJUSTED_TICK_02012025)
            try:
                tradingdatekey = folderName.split("_")[-1]  # Get last part (e.g., 02012025)
                tradingDate = datetime.strptime(tradingdatekey, '%d%m%Y')
                logging.info(f"Trading date: {tradingDate.strftime('%Y-%m-%d')}")
            except Exception as e:
                logging.error(f"Could not parse date from folder name {folderName}: {e}")
                continue
            
            fullExpiryAvailable = tradingDate.date() >= FULL_EXPIRY_DATE_AVAILABLE_FROM
            
            # Fetch MCX expiry data for old format (if needed)
            if fullExpiryAvailable:
                mcxExpiryDict = {}
            else:
                # Try manual mapping first, then API
                mcxExpiryDict = loadManualExpiryMapping()
                if not mcxExpiryDict:
                    logging.info("No manual mapping found, trying MCX API")
                    mcxExpiryDict = getMcxExpiryFromBhavCopy(tradingDate=tradingDate)
            
            # Get all files in the folder
            allFiles = os.listdir(folderPath)
            
            # Process each symbol
            for symbol in SYMBOLS_TO_PROCESS:
                logging.info(f"Processing symbol: {symbol}")
                
                # Single output file for all futures with date in filename
                futureOutputFileName = f"{symbol.lower()}_future_{tradingdatekey}"
                
                # Process futures (combine all 3 into one file)
                for futNo in range(1, 4):  # I, II, III
                    futureFileName = f"{symbol}-{'I'*futNo}.MCX.csv"
                    
                    if futureFileName in allFiles:
                        # Symbol name includes the contract number (e.g., GOLDM-I)
                        symbolName = f"{symbol}-{'I'*futNo}"
                        
                        getFinalDatasetForCSV(
                            dataFilePath=os.path.join(folderPath, futureFileName),
                            optionInfo={"underlyingName": symbol, "symbolName": symbolName, "exchange": "MCX"},
                            outputFileName=futureOutputFileName,
                            isFutureDataFile=True
                        )
                    else:
                        logging.info(f"Future file not found: {futureFileName}")
                
                # Single output files for options with date in filename
                callOutputFileName = f"{symbol.lower()}_call_{tradingdatekey}"
                putOutputFileName = f"{symbol.lower()}_put_{tradingdatekey}"
                
                # Process options (CE and PE)
                symbolFiles = [f for f in allFiles if f.startswith(symbol) and (f.endswith("CE.MCX.csv") or f.endswith("PE.MCX.csv"))]
                
                logging.info(f"Found {len(symbolFiles)} option files for {symbol}")
                
                for optionFile in symbolFiles:
                    # Parse option file name
                    # Example: GOLDM25JAN76000CE.MCX.csv
                    symbolPart = optionFile.replace(".MCX.csv", "")
                    
                    # Determine option type
                    if symbolPart.endswith("CE"):
                        optionType = "call"
                        symbolPart = symbolPart[:-2]
                    elif symbolPart.endswith("PE"):
                        optionType = "put"
                        symbolPart = symbolPart[:-2]
                    else:
                        continue
                    
                    # Extract expiry and strike
                    # Remove symbol name from beginning
                    expiryStrikePart = symbolPart[len(symbol):]
                    
                    try:
                        if fullExpiryAvailable:
                            # New format: GOLDM15JAN2571000PE (7 chars for expiry: DDMMMYY)
                            expiryStr = expiryStrikePart[:7]  # e.g., 15JAN25
                            strikeStr = expiryStrikePart[7:]
                            expiry = datetime.strptime(expiryStr, "%d%b%y")
                        else:
                            # Old format: GOLDM25JAN71000PE (5 chars for expiry: DDMMM)
                            expiryStr = expiryStrikePart[:5]  # e.g., 25JAN
                            strikeStr = expiryStrikePart[5:]
                            
                            # Get full expiry date from MCX BhavCopy data
                            if not mcxExpiryDict:
                                logging.warning(f"No MCX expiry data available, skipping {optionFile}")
                                continue
                            
                            # Convert to format used in MCX dictionary (e.g., "25JAN" -> "25JAN")
                            expiryAlias = expiryStr.upper()
                            
                            # Look up expiry date in MCX dictionary
                            if symbol.upper() not in mcxExpiryDict:
                                logging.warning(f"Symbol {symbol} not found in MCX data, skipping {optionFile}")
                                continue
                            
                            if expiryAlias not in mcxExpiryDict[symbol.upper()]:
                                logging.warning(f"Expiry {expiryAlias} not found for {symbol}, skipping {optionFile}")
                                continue
                            
                            expiry = mcxExpiryDict[symbol.upper()][expiryAlias]
                        
                        strike = float(strikeStr)
                        # Keep expiry in original format DD/MM/YYYY
                        expiryFormatted = expiry.strftime("%d/%m/%Y")
                        
                        # Use appropriate output filename based on option type
                        outputFileName = callOutputFileName if optionType == "call" else putOutputFileName
                        
                        getFinalDatasetForCSV(
                            dataFilePath=os.path.join(folderPath, optionFile),
                            optionInfo={
                                "underlyingName": symbol,
                                "symbolName": symbolPart + ("CE" if optionType == "call" else "PE"),
                                "expiry": expiryFormatted,
                                "strike": strike,
                                "exchange": "MCX"
                            },
                            outputFileName=outputFileName,
                            isFutureDataFile=False
                        )
                    
                    except Exception as e:
                        logging.error(f"Error parsing option file {optionFile}: {e}")
                        continue
        
        logging.info("CSV Processing completed successfully.")
    
    except Exception:
        logging.error(f"Error in main processing: {traceback.format_exc()}")
    
    logging.info("CSV Processing stopped.")

if __name__ == "__main__":
    processFolders()

