################################################################################ importing libraries
from datetime import datetime, time

UPLOAD_DIR = "DataToUpload"
LOG_FILE_FOLDER = "Log Files"
MISSING_DTS_DIR = "Missing Dates"
TICK_DB_UPLOAD_DIR = "TickDataToUpload"

GDFL_FILES_FOLDER = [
    r"C:\mcx_parquet\input"
]
SPECIAL_CHARACTERS = [
    "-", "&"
]

TODAY = datetime.now()

MYSQL_PASSWORD = "master76"
MYSQL_HOST = "192.168.173.180"
MYSQL_USER = "ajay"

MYSQL_TICK_PASSWORD = "master76"
MYSQL_TICK_HOST = "localhost"
MYSQL_TICK_USER = "root"

MARKET_TIMINGS = {
    "NFO": {
        "start": time(9, 15), "end": time(15, 30)
    },
    "BFO": {
        "start": time(9, 15), "end": time(15, 30)
    },
    "MCX": {
        "start": time(9, 0), "end": time(23, 30)
    }
}
VALID_MONTHS = [
    'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
]
WORDS_TO_RM = [
    ".NFO", ".BFO", ".MCX"
]
TO_AVOID = [
    'NIFTYIT', 'NIFTYMID50', 'NIFTYCPSE', "SENSEX50", "GOLDGUINEA", "GOLDPETAL", "SILVERMIC", "ZINCMINI"
]
SYMBOL_CHANGE = {
    "SRTRANSFIN": "SHRIRAMFIN", "MCDOWELL_N": "UNITDSPR", "MOTHERSUMI": "MOTHERSON", "L_TFH": "LTF", "CADILAHC": "ZYDUSLIFE", "PVR": "PVRINOX", "LTI": "LTIM"
}
