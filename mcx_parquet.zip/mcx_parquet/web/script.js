const tickerData = [
  { symbol: "BAJFINANCE", value: 1068.9, change: 27.0 },
  { symbol: "BEL", value: 414.95, change: 6.15 },
  { symbol: "BHARTIARTL", value: 2007.6, change: -87.3 },
  { symbol: "CIPLA", value: 1324.8, change: -8.1 },
  { symbol: "TCS", value: 3980.25, change: 12.55 },
  { symbol: "INFY", value: 1504.9, change: -6.7 },
  { symbol: "RELIANCE", value: 2475.1, change: 18.35 },
  { symbol: "HDFCBANK", value: 1511.75, change: -9.25 },
  { symbol: "SBIN", value: 684.6, change: 3.25 },
  { symbol: "ITC", value: 422.35, change: 1.05 }
];

const indicesData = [
  { name: "NIFTY ALPHA 50", value: 51352, change: 215.6 },
  { name: "NIFTY DIV OPPS 50", value: 6125.05, change: -11.0 },
  { name: "NIFTY GROWSEC 15", value: 11961.25, change: 41.3 },
  { name: "NIFTY 50", value: 25510.7, change: 20.3 },
  { name: "NIFTY NEXT 50", value: 69483.5, change: -175.2 },
  { name: "NIFTY FIN SERVICE", value: 27256.35, change: 51.8 },
  { name: "NIFTY MIDCAP 100", value: 56712.2, change: 509.0 },
  { name: "NIFTY FMCG", value: 52087.55, change: -62.5 }
];

const tickerStrip = document.getElementById("ticker-strip");
const tickerTemplate = document.getElementById("ticker-item-template");
const indicesGrid = document.getElementById("indices-grid");
const indexCardTemplate = document.getElementById("index-card-template");
const feedTimeElements = document.querySelectorAll("[data-feed-time]");
const controlButtons = document.querySelectorAll(".control");
let isStreaming = true;
let tickerPointer = 0;

function formatValue(value) {
  return value.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function computePercent(change, value) {
  const base = value - change;
  if (base === 0) {
    return 0;
  }
  return (change / base) * 100;
}

function formatChange(change, value) {
  const sign = change > 0 ? "+" : change < 0 ? "" : "";
  const percent = computePercent(change, value);
  return `${sign}${change.toFixed(2)} (${percent.toFixed(2)}%)`;
}

function updateFeedTime() {
  const now = new Date();
  const formatted = now.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
  feedTimeElements.forEach((node) => (node.textContent = `${formatted} IST`));
}

function renderTicker() {
  tickerStrip.innerHTML = "";
  const fragment = document.createDocumentFragment();

  for (let i = 0; i < tickerData.length * 2; i += 1) {
    const data = tickerData[i % tickerData.length];
    const item = tickerTemplate.content.firstElementChild.cloneNode(true);
    item.querySelector(".ticker-item__symbol").textContent = data.symbol;
    item.querySelector(".ticker-item__value").textContent = formatValue(data.value);
    item
      .querySelector(".ticker-item__change")
      .textContent = formatChange(data.change, data.value);
    item.classList.toggle("up", data.change >= 0);
    item.classList.toggle("down", data.change < 0);
    fragment.appendChild(item);
  }

  tickerStrip.appendChild(fragment);
}

function renderIndices() {
  indicesGrid.innerHTML = "";
  const fragment = document.createDocumentFragment();

  indicesData.forEach((data) => {
    const tile = indexCardTemplate.content.firstElementChild.cloneNode(true);
    tile.querySelector(".index-tile__name").textContent = data.name;
    tile.querySelector(".index-tile__value").textContent = formatValue(data.value);
    tile
      .querySelector(".index-tile__change")
      .textContent = formatChange(data.change, data.value);
    tile.classList.toggle("up", data.change >= 0);
    tile.classList.toggle("down", data.change < 0);
    fragment.appendChild(tile);
  });

  indicesGrid.appendChild(fragment);
}

function mutateDataFeed() {
  if (!isStreaming) {
    return;
  }

  tickerPointer = (tickerPointer + 1) % tickerData.length;
  const data = tickerData[tickerPointer];
  const delta = (Math.random() - 0.5) * 4;
  const change = parseFloat((delta + data.change).toFixed(2));
  const value = parseFloat((data.value + delta * 2).toFixed(2));
  data.change = change;
  data.value = Math.max(value, 0.01);

  const indexIdx = Math.floor(Math.random() * indicesData.length);
  const index = indicesData[indexIdx];
  const idxDelta = (Math.random() - 0.5) * 0.6;
  index.change = parseFloat((index.change + idxDelta * 55).toFixed(2));
  index.value = parseFloat((index.value + idxDelta * 95).toFixed(2));

  renderTicker();
  renderIndices();
  updateFeedTime();
}

controlButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const action = button.dataset.action;
    if (action === "play") {
      isStreaming = true;
      tickerStrip.classList.remove("paused");
    } else {
      isStreaming = false;
      tickerStrip.classList.add("paused");
    }
  });
});

renderTicker();
renderIndices();
updateFeedTime();

setInterval(mutateDataFeed, 3000);

if ("BroadcastChannel" in window) {
  const channel = new BroadcastChannel("market-feed");
  channel.onmessage = (event) => {
    if (!event.data) {
      return;
    }
    const { symbol, value, change } = event.data;
    const target = tickerData.find((item) => item.symbol === symbol);
    if (target) {
      target.value = value;
      target.change = change;
      renderTicker();
      updateFeedTime();
    }
  };
}

/**
 * Expose a tiny API to the browser console so the user can push updates manually.
 */
window.marketFeed = {
  push(symbol, value, change) {
    const target = tickerData.find((item) => item.symbol === symbol);
    if (!target) {
      return false;
    }
    target.value = value;
    target.change = change;
    renderTicker();
    updateFeedTime();
    return true;
  }
};

