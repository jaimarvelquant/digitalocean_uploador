################################################################################ importing libraries
from time import sleep
import pandas as pd
import subprocess
import traceback
import logging
import config
import shutil
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s')

if os.path.exists(config.TICK_DB_UPLOAD_DIR):
    shutil.rmtree(config.TICK_DB_UPLOAD_DIR)

[os.makedirs(ii, exist_ok=True) for ii in [config.LOG_FILE_FOLDER, config.TICK_DB_UPLOAD_DIR]]

logging.info("Started.")

logging.info("Started option data extractor.")


for ii in range(5):

    try:
        validfutnames = pd.read_csv("https://api.kite.trade/instruments")
        validfutnames = sorted(set(validfutnames[(validfutnames['exchange'] == "MCX") & (validfutnames['instrument_type'] == "FUT")]['name']))[::-1]
        validfutnames = ",".join(validfutnames)
        break

    except Exception:
        logging.error(traceback.format_exc())
        sleep(1)

instutype = ["call", "put", "future"]
indexname = ["COPPER", "CRUDEOILM", "CRUDEOIL", "GOLDM", "GOLD", "NATGASMINI", "NATURALGAS", "SILVERM", "SILVER", "ZINC"]

for instu in instutype:
    for indice in indexname:
        subprocess.run(['python', "prepareTickByTickData.py", indice, instu, 'MCX', validfutnames])

logging.info("Started pushing option data to tick db.")
subprocess.run(['python', "uploadTickDataToDB.py"])

if os.path.exists(config.TICK_DB_UPLOAD_DIR):
    shutil.rmtree(config.TICK_DB_UPLOAD_DIR)

logging.info("Stopped.")
