# Transform Script Structure Analysis

## 📋 Overview
The `transform_official_nautilus.py` script transforms NSE market data (index, futures, options) from Parquet format into NautilusTrader's catalog format.

## 🏗️ Code Structure

### 1. **Imports & Setup** (Lines 1-48)
- Standard library imports
- NautilusTrader imports (models, catalog, wranglers)
- Custom package imports (`marvelquant_data`)
- Logging configuration
- Constants (IST_OFFSET)

### 2. **Utility Functions** (Lines 51-106)
- `bars_to_quote_ticks()`: Converts Bar data to QuoteTicks for Greeks calculation
- `yyyymmdd_seconds_to_datetime()`: Converts integer date/time to UTC datetime

### 3. **Transform Functions** (Lines 109-513)
Three main transformation functions:

#### `transform_index_bars()` (Lines 109-222)
- **Input**: `input_dir/index/{symbol}/**/*.parquet`
- **Process**: 
  - Reads all parquet files for symbol
  - Converts timestamps (IST → UTC)
  - Creates Equity instrument
  - Generates 1-minute bars via BarDataWrangler
  - Writes bars + QuoteTicks to catalog
- **Output**: Bar count

#### `transform_futures_bars()` (Lines 225-359)
- **Input**: `input_dir/futures/{symbol}/**/*.parquet`
- **Process**:
  - Filters for dated files (`{symbol}_future_YYYYMMDD.parquet`)
  - Creates FuturesContract instrument
  - Generates bars + QuoteTicks
  - Creates FutureOI custom data (Open Interest)
- **Output**: (bar_count, None)

#### `transform_options_bars()` (Lines 362-513)
- **Input**: `input_dir/option/{symbol}/**/*.parquet`
- **Process**:
  - Filters for dated call/put files
  - Groups by option symbol
  - Parses NSE option symbols
  - Creates OptionContract for each option
  - Generates bars + QuoteTicks + OptionOI
- **Output**: Total bar count

### 4. **Main Entry Point** (Lines 635-757)
- Argument parsing
- Symbol auto-discovery (if not provided)
- Orchestrates all three transform functions
- Summary output

## 🔴 Critical Issues

### Issue #1: Duplicate/Orphaned Code
**Location**: Lines 516-632
- Contains argument parser and execution logic outside any function
- This code is **unreachable** and will never execute
- Should be **deleted**

### Issue #2: Input Directory Structure Mismatch

**Expected Structure** (by script):
```
input_dir/
├── index/
│   └── nifty/
│       └── *.parquet
├── futures/
│   └── nifty/
│       └── nifty_future_YYYYMMDD.parquet
└── option/
    └── nifty/
        ├── nifty_call_YYYYMMDD.parquet
        └── nifty_put_YYYYMMDD.parquet
```

**Actual Structure** (from your folder):
```
input/
├── 3IINFOTECH/
│   └── 3IINFOTECH_01_04_2011.parquet
├── ABAN/
│   └── ABAN_01_04_2011.parquet
└── ...
```

**Problem**: Script looks for `index/`, `futures/`, `option/` subdirectories, but your data is flat with symbol folders.

### Issue #3: Symbol Auto-Discovery Logic
**Current**: Extracts symbols from filenames using `p.stem.upper()`
- For `3IINFOTECH_01_04_2011.parquet` → symbol = `"3IINFOTECH_01_04_2011"`
- This is **incorrect** - should be just `"3IINFOTECH"`

### Issue #4: File Naming Pattern Assumptions
Script expects:
- Futures: `{symbol}_future_YYYYMMDD.parquet`
- Options: `{symbol}_call_YYYYMMDD.parquet` / `{symbol}_put_YYYYMMDD.parquet`

Your files: `{SYMBOL}_DD_MM_YYYY.parquet` (different format)

## 📊 Data Flow

```
Raw Parquet Files
    ↓
[Read & Combine]
    ↓
[Convert Timestamps: IST → UTC]
    ↓
[Optional Date Filtering]
    ↓
[Data Quality Fixes]
    ↓
[Create Nautilus Instruments]
    ↓
[BarDataWrangler → Bars]
    ↓
[Generate QuoteTicks]
    ↓
[Create OI Data (futures/options)]
    ↓
[Write to ParquetDataCatalog]
    ↓
Nautilus Catalog Format
```

## 🔧 Recommendations

### 1. **Fix Duplicate Code**
Remove lines 516-632 (orphaned code block)

### 2. **Adapt to Your File Structure**
Two options:

**Option A**: Modify script to handle flat structure
- Change `symbol_dir = input_dir / "index" / symbol.lower()` 
- To: `symbol_dir = input_dir / symbol`

**Option B**: Reorganize your data to match expected structure
- Create `index/`, `futures/`, `option/` folders
- Move files accordingly

### 3. **Fix Symbol Discovery**
Extract symbol from filename properly:
```python
# Current (wrong):
discovered = sorted({p.stem.upper() for p in Path(args.input_dir).rglob("*.parquet")})

# Should be:
discovered = sorted({p.parent.name.upper() for p in Path(args.input_dir).rglob("*.parquet")})
# Or parse filename: SYMBOL_DD_MM_YYYY.parquet → SYMBOL
```

### 4. **Handle Different File Formats**
Your files: `{SYMBOL}_DD_MM_YYYY.parquet`
- Need to parse date format `DD_MM_YYYY` instead of `YYYYMMDD`
- May need different file filtering logic

### 5. **Determine Data Type**
Your files don't indicate if they're index/futures/options
- Need metadata or filename pattern to determine type
- Or process all as one type (likely Equity/Index)

## 📁 Expected Output Structure

After transformation, creates:
```
output_dir/
├── bar/
│   └── {INSTRUMENT_ID}-1-MINUTE-LAST-EXTERNAL/
│       └── {TIMESTAMP_RANGE}.parquet
├── quote_tick/
│   └── {INSTRUMENT_ID}/
│       └── {TIMESTAMP_RANGE}.parquet
├── custom_future_oi/  (if futures)
├── custom_option_oi/  (if options)
└── instrument/
    └── {INSTRUMENT_ID}.parquet
```

## ✅ What Works Well

1. **Modular Design**: Separate functions for each data type
2. **Error Handling**: Try-except blocks around file operations
3. **Logging**: Comprehensive logging throughout
4. **Data Quality**: Fixes invalid OHLC relationships
5. **Nautilus Integration**: Uses official patterns (BarDataWrangler)
6. **OI Handling**: Properly handles Open Interest as separate data type

## 🎯 Next Steps

1. **Remove duplicate code** (lines 516-632)
2. **Adapt file discovery** to match your structure
3. **Fix symbol extraction** from filenames
4. **Determine data type** (index/futures/options) or process as Equity
5. **Test with one symbol** before processing all

